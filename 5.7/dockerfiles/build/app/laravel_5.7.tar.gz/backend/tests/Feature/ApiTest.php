<?php

namespace Tests\Feature;

use GuzzleHttp\Client;
use Tests\TestCase;

class ApiTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function testHello()
    {
        $client = new Client();
        $response = $client->get('http://127.0.0.1/test');
        $this->assertEquals($response->getStatusCode(), 200);
        $this->assertEquals($response->getBody(), 'Hello World!');
    }

    public function testConnectionToRedis()
    {
       $client = new Client();
       $resp = $client->get('http://127.0.0.1/redis/connect');
       $this->assertEquals($resp->getStatusCode(), 200);
       $this->assertEquals($resp->getBody(), '1');
    }

    public function testConnectionToRabbit() {
        $client = new Client();
        $resp = $client->get('http://127.0.0.1/rabbit/connect');
        $this->assertEquals($resp->getStatusCode(), 200);
        $this->assertEquals($resp->getBody(), '1');
    }
}
