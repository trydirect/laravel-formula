<?php

use Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Route;

use Illuminate\Support\Facades\Redis;
use Predis\Connection\ConnectionException;
use PhpAmqpLib\Connection\AMQPStreamConnection;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

  /*
  * @api {get} /test
  * @apiName GetHelloWorld
  * @apiVersion 1.0
  *
  * @apiSuccess {String} Hello World!
  *
  */
Route::get('/test', function (Request $request) {
     return "Hello World!";
});


Route::get('/vault/get', function (Request $request) {
    try {
       $client = new Jippi\Vault\Client();
       $data = $client->get('/v1/secret/data/test');
       return response()->json(['data' => $data->getBody()], 200);
    } catch (Exception $e) {
       return $e->getMessage();
    }
});

    /*
     * @api {get} /redis/connect Request for testing connection to Redis
     * @apiName ConnectionRedis
     * @apiVersion 1.0
     *
     * @apiSuccess {Integer} 1
     *
     */
Route::get('/redis/connect', function () {
    try {
        $redis = Redis::connection();
        $is_connected = $redis->isConnected();
        return response($is_connected);
    } catch (ConnectionException $e) {
        return $e->getMessage();
    }
});

    /*
     * @api {get} /rabbit/connect Request for testing connection to RabbitMQ
     * @apiName ConnectionRabbitMQ
     * @apiVersion 1.0
     *
     * @apiSuccess {Integer} 1
     *
     */
Route::get('/rabbit/connect', function () {
    $host = getenv('RABBIT_HOST');
    $port = (int) getenv('RABBIT_PORT');
    $user = getenv('RABBIT_LOGIN');
    $password = getenv('RABBIT_PASSWORD');
    $vhost = getenv('RABBIT_VHOST');
    try {
        $connect = new AMQPStreamConnection($host, $port, $user, $password, $vhost);
        $is_connected = (string)$connect->isConnected();
        return response($is_connected);
    } catch (Exception $e) {
        return $e->getMessage();
    }
});